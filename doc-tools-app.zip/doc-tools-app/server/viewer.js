
const fs = require('fs');

exports.viewFile = async (filePath) => {
  return fs.readFileSync(filePath, 'utf8');
};
