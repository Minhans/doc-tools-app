
window.onload = () => {
  const ad = document.getElementById("ad-space");
  ad.innerHTML = `<iframe src="https://adsense.com/your-ad-code" width="300" height="250"></iframe>`;
};
